from colorama import *
import time
import os

print ("--------------------\n--- Debug Server ---\n--------------------\n")
print ("Box Scripts")
print ("+++++++++++Run Script \n")
time.sleep(1)
print(" 1. htop(Monitoring) \n 2. iftop(View traffic) \n 3. nginx(Create a site page) \n 4. Speed Test(download / upload) \n 5. Hidden IP(CF Script) \n 6. Tunnel Servar(iptabels) \n 7. Exit")
debug=input("What script do you want to install??")
if debug == 1 :
    print (" OK, the operation has started ")
    os.system('apt install htop')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)
elif debug == 2 :
    print (" OK, the operation has started ")
    os.system('apt install iftop')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)
elif debug == 3 :
    print (" OK, the operation has started ")
    os.system('apt install nginx')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)  

elif debug == 4 :
    print (" OK, the operation has started ")
    os.system('curl -s https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py | python3')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(4)
elif debug == 5 :
    print (" OK, the operation has started ")
    os.system('curl https://raw.githubusercontent.com/badafans/better-cloudflare-ip/master/shell/cf.sh -o cf.sh && chmod +x cf.sh && ./cf.sh')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)
elif debug == 6 :
    print (" OK, the operation has started ")
    os.system('apt update && apt list --upgradable && apt list --upgradable -a && apt upgrade -y')
    IPiran= input("Enter the ip server of your tunnel(iran):")
    Ipkharej= input("Enter your main server IP(Your sarver):")
    os.system('sysctl net.ipv4.ip_forward=1')
    os.system('iptables -t nat -A PREROUTING -p tcp --dport 22 -j DNAT --to-destination %s' % IPiran)
    os.system('iptables -t nat -A PREROUTING -j DNAT --to-destination %s' % Ipkharej)
    os.system('iptables -t nat -A POSTROUTING -j MASQUERADE')
    os.system('sysctl net.ipv4.ip_forward=1')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)
    
else : 
    print("Error !! ")   

path = os.path.dirname(__file__)   
path = os.path.join(path, "Run.py")
exec(open(path).read())
