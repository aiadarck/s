import os

print (".  ___        ___ \n  //_\\   ||  //_\\   \n /// \\\  || /// \\\ DARCK \n ----------------- | BOX SCRIPT  \n\n++++ Script Helper Sarvar V2ray \nSubscribe to the YouTube channel @AIADARCK \n\n ")
print(" 1. Update sarver v2ray \n 2. Inestall Panels \n 3. Install SSL Certificate \n 4. Box scripts V2ray \n 5. Debug Server \n 6. Exit\n")
num = input("Enter Number Menu : ")

if num == '1':
    path = os.path.join(os.path.dirname(__file__), "DB/su/UpdateCod.py")
    exec(open(path).read())
elif num == '2':
    path = os.path.join(os.path.dirname(__file__), "DB/su/Panels.py")
    exec(open(path).read())
elif num == '3':
    path = os.path.join(os.path.dirname(__file__), "DB/su/SSL.py")
    exec(open(path).read())
elif num == '4':
    path = os.path.join(os.path.dirname(__file__), "DB/su/BoxScripts.py")
    exec(open(path).read())
elif num == '5':
    path = os.path.join(os.path.dirname(__file__), "DB/su/Debug.py")
    exec(open(path).read())
elif num == '5':
    print("GOOD LUCK")
    exit
       

path = os.path.dirname(__file__)   
path = os.path.join(path, "Run.py")
exec(open(path).read())
