from colorama import *
import time
import os

print ("--------------------\n--- Debug Server ---\n--------------------\n")
print ("Box Scripts")
print ("+++++++++++Run Script \n")
time.sleep(1)
print(" 1. htop(Monitoring) \n 2. iftop(View traffic) \n 3. nginx(Create a site page) \n 4. Exit")
debug=input("What script do you want to install??")
if debug == 1 :
    print (" OK, the operation has started ")
    os.system('apt install htop')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)
elif debug == 2 :
    print (" OK, the operation has started ")
    os.system('apt install iftop')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)
elif debug == 3 :
    print (" OK, the operation has started ")
    os.system('apt install nginx')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)  
elif debug == 4 :
    exit
else : 
    print("Error !! ")   

path = os.path.dirname(__file__)   
path = os.path.join(path, "Run.py")
exec(open(path).read())
