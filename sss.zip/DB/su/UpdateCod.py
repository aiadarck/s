from colorama import *
import time
import os


print ("--------------------\n-- update Sarver ---\n--------------------\n")
print ("Update Server Panel")
print ("+++++++++++Run Script ")
time.sleep(1)
print ("\n\n Wait until the fry is finished ....\n")
time.sleep(2)
print ("1. Fix Error Update Server (broken)")
os.system('apt --fix-broken install -y')
print(Fore.GREEN, "Done", Fore.RESET)
time.sleep(2)
print ("2. Update ")
os.system('apt update')
print(Fore.GREEN, "Done", Fore.RESET)
time.sleep(2)
print ("3. Update Surse Server ")
os.system('apt list --upgradable && apt list --upgradable -a ')
print(Fore.GREEN, "Done", Fore.RESET)
time.sleep(2)
print ("4. Upgrade Server ")
os.system('apt upgrade -y')
print(Fore.GREEN, "Done", Fore.RESET)
time.sleep(2)
quit1 = input("If you installed X-UI on your server, should I restart the panel? (y/n) : ")
if quit1 == 'y':
    print ("5. ok. Restart x-ui ")
    os.system('x-ui restart')
    print(Fore.GREEN, "Done", Fore.RESET)
    time.sleep(2)
    print("ok. Return to the main menu")
elif quit1 == 'n':
    print("ok. Return to the main menu")
else :
    exit            

path = os.path.dirname(__file__)   
path = os.path.join(path, "Run.py")
exec(open(path).read())