import time
from sys import executable
from subprocess import run


print ("--------------------\n-- update Sarver ---\n--------------------\n")
print ("+++++++++++Run Script \n")
time.sleep(2)
print ("\n\n Wait until the fry is finished ....")


Done = print ("Done")
run('\..\Run.py')